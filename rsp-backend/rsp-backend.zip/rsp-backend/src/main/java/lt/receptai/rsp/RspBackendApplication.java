package lt.receptai.rsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RspBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(RspBackendApplication.class, args);
	}

}
